﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CharacterBehaviors
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            Theif Char1 = new Theif( 100, 110, "Bob", 100);
            Console.WriteLine(Char1.ToString());

            Console.WriteLine("The grand adventures of Bob the theif.");
            Console.WriteLine("bob started off his day by trying to rob a bank. \n On the escape, he fell down the stairs.");
            Char1.ChangeHealth(Char1.Attack());
            Console.WriteLine(Char1.Health+" Health remaining");
            Console.WriteLine(" The guards were attacking and throwing rocks at bob as he fled down the streets. Two rocks happened to graze him");
            Char1.ChangeHealth(Char1.Attack());
            Char1.ChangeHealth(Char1.Attack());
            Console.WriteLine(Char1.Health + " Health remaining");
            if(Char1.IsDead()==true){
                Console.WriteLine("Bob died");
                Environment.Exit(0);
            }
            Console.WriteLine("After a few corners and turns, Bob thought he had lost the guards, when suddenly!");
            Char1.ChangeHealth(Char1.Attack());
            Console.WriteLine(Char1.Health + " Health remaining");
            if (Char1.IsDead() == true)
            {
                Console.WriteLine("Bob died");
                Environment.Exit(0);
            }
            Console.WriteLine("A guard Turned a corner and wacked Bob in the face. Bob stood there in fright and decicde what to do");
            Console.WriteLine("Bob decided that it was "+Char1.HasFled()+"ly a good idea to run and sprinted away from the guards");
            Console.WriteLine("As he ran he saw more and more guards chasing him. These ones decided to throw spears. one of them grazed his shoulder.");
            Char1.ChangeHealth(Char1.Attack());
            Console.WriteLine(Char1.Health + " Health remaining");
            if (Char1.IsDead() == true)
            {
                Console.WriteLine("Bob died");
                Environment.Exit(0);
            }
            Console.WriteLine("Bob was cornered now Hit after hit fell upon him and he saw his life flash before his eyes.");
            Char1.ChangeHealth(Char1.Attack());
            Char1.ChangeHealth(Char1.Attack());
            Char1.ChangeHealth(Char1.Attack());
            Char1.ChangeHealth(Char1.Attack());
            Console.WriteLine(Char1.Health + " Health remaining");
            if (Char1.IsDead() == true)
            {
                Console.WriteLine("Bob died");
                Environment.Exit(0);
            }
            Console.WriteLine("But magically, Bob went super and killed all the guards, then walked away with dignity and happiness.");
            Console.WriteLine("The end");



*/
            Random rng = new Random();
            List<CommonCharacter> Characters=new List<CommonCharacter>();

            Characters.Add(new wizard(100,10,"Tim",9000));
            Characters.Add(new Theif(100, 10, "Bob", 90));
            Characters.Add(new wizard(100, 10, "Malcom", 0));
            Characters.Add(new Theif(100, 10, "Deathwatch", 1));

            while (Characters.Count() > 1)
            {
                int who=1;
                for(int i=0; i<Characters.Count();i++){
                    int attack=Characters.ElementAt(i).Attack();
                     who = rng.Next(Characters.Count());
                    Characters.ElementAt(who).ChangeHealth(attack);
                    Console.WriteLine(Characters.ElementAt(i).Name + " has attacked " + Characters.ElementAt(who).Name + " and dealt " + attack + " Damage");
                
                    if(Characters.ElementAt(who).Health<=0){
                        Console.WriteLine(Characters.ElementAt(who).Name+" has died");
                        Characters.RemoveAt(who);

                       
                    } 
                    else if (Characters.ElementAt(who).HasFled()) {
                            Console.WriteLine(Characters.ElementAt(who).Name+" has fled" );
                            Characters.RemoveAt(who);
                        }
                        System.Threading.Thread.Sleep(1000); 
                }
}
            
            Console.WriteLine(Characters.ElementAt(0).Name + " has won");

        }
    }
}
