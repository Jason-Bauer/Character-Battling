﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CharacterBehaviors
{
    class wizard: CommonCharacter
    {
        private int POWER;
         public wizard(int S, int L, string N, int power)
            : base(100,S,L,N,"Wizard")
        {
             POWER = power;
        }

        public override int Attack()
        {
            Random rng = new Random();
            int DamageDone = 0;
            int percent = rng.Next(100) + 1;
            if (percent >= 1 && percent <= 30)
            {
                DamageDone = 0;
            }
            else if (percent >= 30 && percent <= 50)
            {
                DamageDone = rng.Next(5) + 11;
            }
            else if (percent >= 50 && percent <= 100)
            {
                DamageDone = rng.Next(5) + 16;
            }
           
            return DamageDone;
        }
        public override bool HasFled()
        {
            bool Fleeing = false;
            return Fleeing;
        }

    }
}
