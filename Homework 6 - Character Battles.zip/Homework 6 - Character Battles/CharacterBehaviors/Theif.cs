﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CharacterBehaviors
{
    class Theif: CommonCharacter
    {
        Random rng = new Random();
        int SneakySkill;

        public int sneakySkill
        {
            get { return SneakySkill; }
        }
        public Theif() : base() 
{

}
        public Theif(int S, int L, string N, int Sneak)
            : base(70,S,L,N,"Theif")
        {
             SneakySkill = Sneak;
        }

        public override string ToString()
        {
            string sa= ("Level is "+ Level +" \n Health is "+ Health+ "\n Stamina is "+ Stamina+ " \n Name is "+ Name+ "\n Job is "+Job+ " \n Sneaking Skill is "+sneakySkill);
            return sa;

        }



    }
}
