﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CharacterBehaviors
{
    
    class CommonCharacter
    {
        Random rng = new Random();
        private int health;
        private int stamina;
        private int level;
        private string name;
        private string job;

        public int Health
        {
            get { return health; }
            set { health =  value; }
        }
        public int Stamina
        {
            get { return stamina; }
        }
        public int Level
        {
            get { return level; }
        }
        public string Name
        {
            get { return name; }
        }
        public string Job
        {
            get { return job; }
        }

        public CommonCharacter() {
            health = 100;
            stamina = 100;
            level = 1;
            name = "Peasant";
            job = " Peasant";
        }
        public CommonCharacter(int H, int S, int L, string N, string J) {
            health = H;
            stamina = S;
            level = L;
            name = N;
            job = J;
        }

    public virtual int Attack() { 
        int DamageDone=0;
        int percent = rng.Next(100)+1;
        if (percent >= 1 && percent <= 25) {
            DamageDone = 0;
        }
        else if (percent >= 25 && percent <= 45) {
            DamageDone = rng.Next(5) + 1;
        }
        else if (percent >= 45 && percent <= 65) {
            DamageDone = rng.Next(5) + 6;
        }
        else if (percent >= 65 && percent <= 85)
        {
            DamageDone = rng.Next(5) + 11;
        }
        else if (percent >= 85 && percent <= 100)
        {
            DamageDone = rng.Next(5) + 16;
        }
        return DamageDone;
        }

        public virtual bool IsDead() {
            bool dead = true;
            if (Health > 0)
            {
                dead = false;
            }

            return dead;

        }

        public virtual void ChangeHealth(int amount) {
            Health = Health - amount;
            if (Health > 100) { Health = 100; }
            else if (Health < 0) { Health = 0; }

        }

        public virtual bool HasFled()
        {
            bool Fleeing = false;
            if (health < 10)
            {
                Fleeing = true;
            }
            return Fleeing;
        }


    }
}
